﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace MPS.Entity.CreateItemDownload
{
    public class UploadFileInfo
    {
        public int BatchFileID { get; set; }

        [XmlElement(IsNullable = false)]
        public string ProcessStatus { get; set; }

        [XmlElement(IsNullable = false)]
        public string Description { get; set; }

        [XmlElement(IsNullable = false)]
        public string LogFilePath { get; set; }

        [XmlElement(IsNullable = false)]
        public string IsProcessed { get; set; }

        public int? RetryCount { get; set; }

        [XmlIgnore]
        public bool RetryCountSpecified { get { return (RetryCount != null && RetryCount.HasValue); } }

        [XmlElement(IsNullable = false)]
        public string EditUser { get; set; }

        [XmlElement(IsNullable = false)]
        public string ProcessSteps { get; set; }

        [XmlElement(IsNullable = false)]
        public string ProcessServerIP { get; set; }

    }
}
