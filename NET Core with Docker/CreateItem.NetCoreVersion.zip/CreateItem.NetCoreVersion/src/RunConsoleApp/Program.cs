﻿using MPS.BatchCreateItemDownload;
using MPS.DataAccess.SQLAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RunConsoleApp
{
    public class Program
    {
        public static void Main(string[] args)
        {
            try
            {
                HandleFileProcess batchCreateItemDownloadProcess = new HandleFileProcess();
                batchCreateItemDownloadProcess.Run();


            }
            catch (Exception ex)
            {
                Console.WriteLine($"Process Run Exception \r{ex.Message} \r{ex.StackTrace}");
            }

            Console.Read();
        }
    }
}
