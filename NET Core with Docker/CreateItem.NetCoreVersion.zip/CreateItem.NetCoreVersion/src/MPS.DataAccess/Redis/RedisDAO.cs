﻿using StackExchange.Redis;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization.Json;
using System.Threading.Tasks;

namespace MPS.DataAccess.Redis
{
    /// <summary>
    /// use 3 party library：StackExchange.Redis
    /// https://github.com/StackExchange/StackExchange.Redis
    /// </summary>
    public class RedisDAO : IDisposable
    {
        #region 改至 Config 配置

        private static string HostString = "172.16.16.177:8211,172.16.16.177:8212"; //GQC

        #endregion

        private static ConnectionMultiplexer Pool = null;

        public RedisDAO() : this(null) { }

        public RedisDAO(string Hosts)
        {
            Pool = GetConnection(Hosts);
        }

        private ConnectionMultiplexer GetConnection(string Hosts)
        {
            var config = string.IsNullOrEmpty(Hosts) ? HostString : Hosts;
            ConnectionMultiplexer conn = ConnectionMultiplexer.Connect(config);
            List<IServer> masters = new List<IServer>();
            List<IServer> slaves = new List<IServer>();

            foreach (var endpoint in conn.GetEndPoints())
            {
                var server = conn.GetServer(endpoint);

                if (server != null && server.IsConnected)
                {
                    if (server.IsSlave)
                        slaves.Add(server);
                    else
                        masters.Add(server);
                }
            }

            return conn;
        }

        private byte[] Serialize<T>(object o)
        {
            if (o == null) return null;

            try
            {
                using (System.IO.MemoryStream ms = new System.IO.MemoryStream())
                {
                    DataContractJsonSerializer js = new DataContractJsonSerializer(typeof(T));
                    js.WriteObject(ms, o);
                    return ms.ToArray();
                }
            }
            catch
            {
                return null;
            }
        }

        private T Deserialize<T>(byte[] stream)
        {
            if (stream == null) return default(T);

            try
            {
                DataContractJsonSerializer js = new DataContractJsonSerializer(typeof(T));

                using (System.IO.MemoryStream ms = new System.IO.MemoryStream(stream))
                {
                    return (T)js.ReadObject(ms);
                }
            }
            catch (Exception e)
            {
                return default(T);
            }
        }

        /// <summary>
        /// Search key from Redis
        /// </summary>
        /// <param name="key">DataKey</param>
        /// <returns>DataKey exists or not</returns>
        public bool RedisContainsKey(string key)
        {
            var db = Pool.GetDatabase();
            return db.KeyExists(key);
        }

        /// <summary>
        /// Remove a data by key
        /// </summary>
        /// <param name="key"></param>
        /// <returns>Succeed or not</returns>
        public bool RedisRemoveKey(string key)
        {
            var db = Pool.GetDatabase();
            return db.KeyDelete(key);
        }

        /// <summary>
        /// Get data from Redis
        /// </summary>
        /// <typeparam name="T">DataType</typeparam>
        /// <param name="prsm">PooledRedisClientManager</param>
        /// <param name="key">DataKey</param>
        /// <returns>Data</returns>
        public T RedisGet<T>(string key)
        {
            T value = default(T);

            try
            {
                var db = Pool.GetDatabase();
                value = Deserialize<T>(db.StringGet(key));
            }
            catch (Exception ex)
            {
                //if (Regex.IsMatch(ex.Message, @"MOVED \w* \d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\:\d+"))
                //    return RedisGet<T>(key, Regex.Match(ex.Message, @"\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\:\d+").Value);
                //else
                throw ex;
            }

            return value;
        }

        /// <summary>
        /// Set data to Redis
        /// </summary>
        /// <typeparam name="T">DataType</typeparam>
        /// <param name="prsm">PooledRedisClientManager</param>
        /// <param name="key">DataKey</param>
        /// <param name="value">Data</param>
        /// <returns>Set is success or not</returns>
        public bool RedisSet<T>(string key, T value)
        {
            return RedisSet<T>(key, value, null);
        }

        /// <summary>
        /// Set data to Redis
        /// </summary>
        /// <typeparam name="T">DataType</typeparam>
        /// <param name="key">DataKey</param>
        /// <param name="value">Data</param>
        /// <param name="timespan">Data live time</param>
        /// <returns>Set is success or not</returns>
        public bool RedisSet<T>(string key, T value, string timespan = null)
        {
            var db = Pool.GetDatabase();

            if (string.IsNullOrEmpty(timespan))
                return db.StringSet(key, Serialize<T>(value));
            else
                return db.StringSet(key, Serialize<T>(value), TimeSpan.Parse(timespan));
        }

        public void Dispose()
        {
            Pool.Dispose();
        }
    }
}
