﻿using MPS.Common.Serializer;
using MPS.Common.Web;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MPS.DataAccess.SpiderLog
{
    public class SpiderLogDAO
    {
        #region 改至 Config 配置

        private static string SpiderURL = "http://apis.newegg.org/spider/v1/event";

        #endregion

        public static void SpiderLog(List<Spider> spider)
        {
            Task.Factory.StartNew(() =>
            {
                var msg = SerializerHelper.JsonSerializer(spider);
                ServiceHelper.CallSpiderLogServiceByJson(SpiderURL, msg);
            });
        }

        public static void CallSpiderLogV1(string tAction, string tLabel, DateTime? dtStart)
        {
            if (dtStart == null) return;

            DateTime dtEnd = DateTime.Now;

            Spider obj = new Spider()
            {
                Module = "MPS_DataFeed_ItemCreation",
                Action = tAction,
                StartDate = dtStart.Value,
                EndDate = dtEnd,
                Label = tLabel,
                OperateUser = "Job",
                Value = (int)((dtEnd - dtStart.Value).TotalMilliseconds)
            };

            SpiderLog(new List<Spider> { obj });
        }

        public static void CallSpiderLogAverage(string LogAction, int ItemCount, double TotalMilliseconds)
        {
            if (string.IsNullOrWhiteSpace(LogAction)) return;

            int AverageTime = (int)(TotalMilliseconds / ItemCount);
            DateTime EndTime = DateTime.Now;
            DateTime StartTiem = EndTime.AddMilliseconds(AverageTime * -1);

            Spider obj = new Spider()
            {
                Module = "MPS_DataFeed_ItemCreation",
                Action = LogAction,
                StartDate = StartTiem,
                EndDate = EndTime,
                Label = "Item count:1",
                OperateUser = "Job",
                Value = AverageTime
            };

            SpiderLog(new List<Spider> { obj });
        }
    }
}
