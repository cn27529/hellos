﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MPS.DataAccess.SpiderLog
{
    public class Spider
    {
        public string Module { get; set; }
        public string Action { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string Label { get; set; }
        public string OperateUser { get; set; }
        public int Value { get; set; }
    }
}
