﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Serialization;
using Dapper;
using System.Data;

namespace MPS.DataAccess.SQLAccess
{
    [XmlRoot("dataOperations")]
    public class DataCommandConfig
    {
        [XmlElement("dataCommand")]
        public List<DataCommand> DataCommands { get; set; }
    }

    /// <summary>
    /// use 3 party library：Dapper
    /// https://github.com/StackExchange/dapper-dot-net
    /// </summary>
    [XmlRoot("dataCommand")]
    public class DataCommand
    {
        [XmlAttribute("name")]
        public string Name { get; set; }

        [XmlAttribute("database")]
        public string Database { get; set; }

        [XmlAttribute("commandType")]
        public string CommandType { get; set; }

        [XmlElement("commandText")]
        public string CommandText { get; set; }

        [XmlArray("parameters"), XmlArrayItem("param")]
        public List<Parameter> Parameters { get; set; }

        public void SetParameterValue(string parameterName, object parameterValue)
        {
            Parameter parameter = Parameters.SingleOrDefault(p => p.Name == parameterName);

            if (parameter != null) parameter.Value = parameterValue;
        }

        public void ReplaceParameterValue(string source, string value)
        {
            CommandText = CommandText.Replace(source, value);
        }

        public int ExecuteNonQuery()
        {
            using (SqlConnection connection = DataCommandHelper.GetSqlConnection(Database))
            {
                return connection.Execute(CommandText, DataCommandHelper.GetParameters(Parameters), commandType: DataCommandHelper.GetCommandType(CommandType));
            }
        }

        /// <summary>
        /// 執行命令並取得 Output 參數：
        /// int r = cmd.ExecuteOutput<int>("@r");
        /// </summary>
        /// <returns></returns>
        public void ExecuteOutput<T, K>(string parameterName1, string parameterName2, out T result1, out K result2)
        {
            DynamicParameters dParameters = ExecuteOutput();
            result1 = dParameters.Get<T>(parameterName1);
            result2 = dParameters.Get<K>(parameterName2);
        }

        /// <summary>
        /// 執行命令並取得 Output 參數：
        /// int r = cmd.ExecuteOutput<int>("@r");
        /// </summary>
        /// <returns></returns>
        public T ExecuteOutput<T>(string parameterName)
        {
            DynamicParameters dParameters = ExecuteOutput();
            return dParameters.Get<T>(parameterName);
        }

        /// <summary>
        /// 執行命令並取得多個 Output 參數：
        /// var dParameters = cmd.ExecuteOutput();
        /// int r1 = dParameters.Get<int>("@r1");
        /// string r2 = dParameters.Get<string>("@r2");
        /// </summary>
        /// <returns></returns>
        public DynamicParameters ExecuteOutput()
        {
            using (SqlConnection connection = DataCommandHelper.GetSqlConnection(Database))
            {
                DynamicParameters dParameters = DataCommandHelper.GetParameters(Parameters);
                connection.Execute(CommandText, dParameters, commandType: DataCommandHelper.GetCommandType(CommandType));
                return dParameters;
            }
        }

        public T ExecuteEntity<T>()
        {
            using (SqlConnection connection = DataCommandHelper.GetSqlConnection(Database))
            {
                return connection.QueryFirstOrDefault<T>(CommandText, DataCommandHelper.GetParameters(Parameters), commandType: DataCommandHelper.GetCommandType(CommandType));
            }
        }

        public List<T> ExecuteEntityList<T>()
        {
            using (SqlConnection connection = DataCommandHelper.GetSqlConnection(Database))
            {
                return connection.Query<T>(CommandText, DataCommandHelper.GetParameters(Parameters), commandType: DataCommandHelper.GetCommandType(CommandType)).ToList();
            }
        }

        /// <summary>
        /// 一次執行多組查詢 分別取出查詢結果
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <typeparam name="K"></typeparam>
        /// <param name="result1"></param>
        /// <param name="result2"></param>
        public void ExecuteMultipleSingleAndList<T, K>(out T result1, out List<K> result2)
        {
            using (SqlConnection connection = DataCommandHelper.GetSqlConnection(Database))
            {
                SqlMapper.GridReader gr = ExecuteMultiple();
                result1 = gr.Read<T>().SingleOrDefault();
                result2 = gr.Read<K>().ToList();
            }
        }

        /// <summary>
        /// 一次執行多組查詢 分別取出查詢結果
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <typeparam name="K"></typeparam>
        /// <typeparam name="M"></typeparam>
        /// <param name="result1"></param>
        /// <param name="result2"></param>
        /// <param name="result3"></param>
        public void ExecuteMultipleSingleAndList<T, K, M>(out T result1, out List<K> result2, out List<M> result3)
        {
            using (SqlConnection connection = DataCommandHelper.GetSqlConnection(Database))
            {
                SqlMapper.GridReader gr = ExecuteMultiple();
                result1 = gr.Read<T>().SingleOrDefault();
                result2 = gr.Read<K>().ToList();
                result3 = gr.Read<M>().ToList();
            }
        }

        /// <summary>
        /// 一次執行多組查詢 分別取出查詢結果
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <typeparam name="K"></typeparam>
        /// <param name="result1"></param>
        /// <param name="result2"></param>
        public void ExecuteMultipleList<T, K>(out List<T> result1, out List<K> result2)
        {
            using (SqlConnection connection = DataCommandHelper.GetSqlConnection(Database))
            {
                SqlMapper.GridReader gr = ExecuteMultiple();
                result1 = gr.Read<T>().ToList();
                result2 = gr.Read<K>().ToList();
            }
        }

        /// <summary>
        /// 一次執行多組查詢 分別取出查詢結果
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <typeparam name="K"></typeparam>
        /// <typeparam name="M"></typeparam>
        /// <param name="result1"></param>
        /// <param name="result2"></param>
        /// <param name="result3"></param>
        public void ExecuteMultipleList<T, K, M>(out List<T> result1, out List<K> result2, out List<M> result3)
        {
            using (SqlConnection connection = DataCommandHelper.GetSqlConnection(Database))
            {
                SqlMapper.GridReader gr = ExecuteMultiple();
                result1 = gr.Read<T>().ToList();
                result2 = gr.Read<K>().ToList();
                result3 = gr.Read<M>().ToList();
            }
        }

        /// <summary>
        /// 一次執行多組查詢 分別取出查詢結果
        /// EX SQL Command：
        /// SELECT * FROM Sellers WHERE SellerID = @SellerID
        /// SELECT * FROM Customers WHERE CustomerId = @CustomerId
        /// SELECT* FROM Orders WHERE CustomerId = @CustomerId
        /// 回傳 SqlMapper.GridReader 物件：
        /// var multi = cmd.ExecuteMultiple();
        /// 取值方式：
        /// var seller = multi.Read<Seller>().SingleOrDefault();
        /// var customers = multi.Read<Customer>().ToList();
        /// var customerOrders = multi.Read<Order>().ToList();
        /// </summary>
        /// <returns></returns>
        public SqlMapper.GridReader ExecuteMultiple()
        {
            using (SqlConnection connection = DataCommandHelper.GetSqlConnection(Database))
            {
                return connection.QueryMultiple(CommandText, DataCommandHelper.GetParameters(Parameters), commandType: DataCommandHelper.GetCommandType(CommandType));
            }
        }

        /// <summary>
        /// EX SQL Command：
        /// INSERT INTO Region (Id, Desc) VALUES (@Id, @Desc)
        /// 直接使用資料物件的屬性名稱與 SQL Command 中的變數名稱做配對
        /// 可以不須配置 SQL Command 中的 parameters 節點資訊 在程式中也不需要呼叫 SetParameterValue
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="data"></param>
        /// <returns></returns>
        public int ExecuteInsert<T>(T data)
        {
            using (SqlConnection connection = DataCommandHelper.GetSqlConnection(Database))
            {
                return connection.Execute(CommandText, param: data, commandType: DataCommandHelper.GetCommandType(CommandType));
            }
        }

        /// <summary>
        /// EX SQL Command：
        /// INSERT INTO Region (Id, Desc) VALUES (@Id, @Desc)
        /// 直接使用資料物件的屬性名稱與 SQL Command 中的變數名稱做配對
        /// 可以不須配置 SQL Command 中的 parameters 節點資訊 在程式中也不需要呼叫 SetParameterValue
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="data"></param>
        /// <returns></returns>
        public int ExecuteMultipleInsert<T>(List<T> datas)
        {
            using (SqlConnection connection = DataCommandHelper.GetSqlConnection(Database))
            {
                return connection.Execute(CommandText, param: datas, commandType: DataCommandHelper.GetCommandType(CommandType));
            }
        }
    }

    [XmlRoot("param")]
    public class Parameter
    {
        [XmlAttribute("name")]
        public string Name { get; set; }

        [XmlAttribute("dbType")]
        public string DbType { get; set; }

        [XmlAttribute("direction")]
        public string Direction { get; set; }

        [XmlAttribute("size")]
        public string Size { get; set; }

        public object Value { get; set; }
    }
}
