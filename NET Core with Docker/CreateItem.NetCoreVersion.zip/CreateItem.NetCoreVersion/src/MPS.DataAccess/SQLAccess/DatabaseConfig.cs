﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace MPS.DataAccess.SQLAccess
{
    [XmlRoot("databaseList")]
    public class DatabaseConfig
    {
        [XmlElement("database")]
        public List<Database> DatabaseList { get; set; }
    }

    [XmlRoot("database")]
    public class Database
    {
        [XmlAttribute("name")]
        public string Name { get; set; }

        [XmlElement("connectionString")]
        public string ConnectionString { get; set; }
    }
}
