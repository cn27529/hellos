﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace MPS.DataAccess.SQLAccess
{
    public class DataCommandHelper
    {
        public static DbType GetDbType(string dbType)
        {
            switch (dbType)
            {
                case "AnsiString":
                    return DbType.AnsiString;
                case "AnsiStringFixedLength":
                    return DbType.AnsiStringFixedLength;
                case "Boolean":
                    return DbType.Boolean;
                case "DateTime":
                    return DbType.DateTime;
                case "Decimal":
                    return DbType.Decimal;
                case "Double":
                    return DbType.Double;
                case "Guid":
                    return DbType.Guid;
                case "Int32":
                    return DbType.Int32;
                case "Int64":
                    return DbType.Int64;
                case "Single":
                    return DbType.Single;
                case "String":
                    return DbType.String;
                case "StringFixedLength":
                    return DbType.StringFixedLength;
                case "Xml":
                    return DbType.Xml;
                default:
                    return DbType.String;
            }
        }

        public static ParameterDirection GetDirection(string direction)
        {
            switch (direction)
            {
                case "Input":
                    return ParameterDirection.Input;
                case "Output":
                    return ParameterDirection.Output;
                default:
                    return ParameterDirection.Input;
            }
        }

        public static CommandType GetCommandType(string commandType)
        {
            switch (commandType)
            {
                case "Text":
                    return CommandType.Text;
                case "StoredProcedure":
                    return CommandType.StoredProcedure;
                default:
                    return CommandType.Text;
            }
        }

        public static DynamicParameters GetParameters(List<Parameter> parameters)
        {
            var result = new DynamicParameters();

            foreach (var par in parameters)
            {
                int size;

                if (int.TryParse(par.Size, out size))
                    result.Add(par.Name, par.Value, GetDbType(par.DbType), GetDirection(par.Direction), size);
                else
                    result.Add(par.Name, par.Value, GetDbType(par.DbType), GetDirection(par.Direction));
            }

            return result;
        }

        public static SqlConnection GetSqlConnection(string databaseName)
        {
            Database databaseInfo = DataCommandManager.GetDatabase(databaseName);
            return new SqlConnection(databaseInfo.ConnectionString);
        }
    }
}
