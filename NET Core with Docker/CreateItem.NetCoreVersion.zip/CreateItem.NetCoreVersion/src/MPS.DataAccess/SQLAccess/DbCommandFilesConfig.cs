﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace MPS.DataAccess.SQLAccess
{
    [XmlRoot("dataCommandFiles")]
    public class DbCommandFilesConfig
    {
        [XmlElement("file")]
        public List<CommandFile> CommandFiles { get; set; }
    }

    [XmlRoot("file")]
    public class CommandFile
    {
        [XmlAttribute("name")]
        public string Name { get; set; }
    }
}
