﻿using MPS.Common.Serializer;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace MPS.DataAccess.SQLAccess
{
    public static class DataCommandManager
    {
        #region 改至 Config 配置

        //SQL 配置檔基礎路徑
        public static string DbCommandBasePath = Path.Combine(AppContext.BaseDirectory, "SQLConfiguration");
        //Database Connection 配置檔路徑
        public static string DatabasePath = Path.Combine(DbCommandBasePath, "Database.config");
        //Command Files 配置檔路徑
        public static string DbCommandFilesPath = Path.Combine(DbCommandBasePath, "DbCommandFiles.config");

        #endregion 

        private static DatabaseConfig databaseConfig;
        private static DbCommandFilesConfig dbCommandFilesConfig;
        private static List<DataCommandConfig> dataCommandConfigs;

        static DataCommandManager()
        {
            databaseConfig = LoadDatabaseConfig();
            dbCommandFilesConfig = LoadDbCommandFilesConfig();
            dataCommandConfigs = LoadDataCommandConfigs();
        }

        private static DatabaseConfig LoadDatabaseConfig()
        {
            DatabaseConfig result = null;

            if (File.Exists(DatabasePath))
            {
                result = SerializerHelper.OpenXmlDeserializeEntity<DatabaseConfig>(DatabasePath);

                if (result == null) throw new NullReferenceException("Can not deserialize Database.config");
            }
            else
                throw new FileNotFoundException("Can not found Database.config");

            return result;
        }

        private static DbCommandFilesConfig LoadDbCommandFilesConfig()
        {
            DbCommandFilesConfig result = null;

            if (File.Exists(DbCommandFilesPath))
            {
                result = SerializerHelper.OpenXmlDeserializeEntity<DbCommandFilesConfig>(DbCommandFilesPath);

                if (result == null) throw new NullReferenceException("Can not deserialize DbCommandFiles.config");
            }
            else
                throw new FileNotFoundException("Can not found DbCommandFiles.config");

            return result;
        }

        private static List<DataCommandConfig> LoadDataCommandConfigs()
        {
            List<DataCommandConfig> result = new List<DataCommandConfig>();

            foreach (CommandFile cf in dbCommandFilesConfig.CommandFiles)
            {
                string commandFilePath = Path.Combine(DbCommandBasePath, cf.Name);

                if (File.Exists(commandFilePath))
                {
                    DataCommandConfig dcc = SerializerHelper.OpenXmlDeserializeEntity<DataCommandConfig>(commandFilePath);

                    if (dcc != null)
                        result.Add(dcc);
                    else
                        throw new FileNotFoundException($"Can not deserialize {cf.Name}");
                }
                else
                    throw new FileNotFoundException($"Can not found {cf.Name}");
            }

            return result;
        }

        public static DataCommand GetDataCommand(string commandName)
        {
            DataCommand result = null;

            foreach (DataCommandConfig com in dataCommandConfigs)
            {
                result = com.DataCommands.SingleOrDefault(c => c.Name == commandName);

                if (result != null) break;
            }

            if (result == null)
                throw new MissingMemberException($"Can not found {commandName} in all sql command configs");
            else
                return result;
        }

        public static Database GetDatabase(string databaseName)
        {
            Database result = databaseConfig.DatabaseList.SingleOrDefault(d => d.Name == databaseName);

            if (result == null)
                throw new MissingMemberException($"Can not found {databaseName} in Database.config");
            else
                return result;
        }
    }
}
