﻿using MPS.DataAccess.CreateItemDownload;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MPS.DataAccess
{
    /// <summary>
    /// 列舉存取資料庫模式 
    /// </summary>
    public enum DBModeType
    {
        SQLServer = 1,
        HBase = 2,
        SQLServerAndHBase_BaseOnHBase = 3,
        SQLServerAndHBase_BaseOnSQLServer = 4,
        NoHbase = 5
    }

    public class DBFactory
    {
        #region 改至 Config 配置

        //1:SQL 5:NoHbase
        public static int DBMode = 5;

        #endregion

        public static ICreateItemDownloadDAO GetCreateItemDownloadInstance()
        {
            ICreateItemDownloadDAO dbInstance = null;
            DBModeType dbModeType;

            if (Enum.TryParse<DBModeType>(DBMode.ToString(), out dbModeType))
            {
                switch (dbModeType)
                {
                    case DBModeType.SQLServer:
                        dbInstance = new SQLCreateItemDownloadDAO();
                        break;
                    case DBModeType.NoHbase:
                        dbInstance = new NoHBaseCreateItemDownloadDAO();
                        break;
                    default:
                        throw new TypeAccessException("The DBMode config setting is not supported.");
                }
            }
            else
                throw new TypeAccessException("The DBMode config setting is not supported.");

            return dbInstance;
        }
    }
}
