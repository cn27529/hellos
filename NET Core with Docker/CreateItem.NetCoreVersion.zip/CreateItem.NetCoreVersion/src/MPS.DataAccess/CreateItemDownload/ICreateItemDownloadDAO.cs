﻿using MPS.POCO.Entity.CreateItemDownload;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MPS.DataAccess.CreateItemDownload
{
    public interface ICreateItemDownloadDAO
    {
        InboundBatchFileInfo GetInboundBatchCreateItemFileList_V2(string preTestSellerList, string emailTo, int topCount, string serverIP, int sellerType, string countryCode, string specficSellerStr);

        void UpdateDataFeedFailed(int transactionNumber, string errorMessage);

        void UpdateDownloadFailed(InboundBatchFileInfo fileInfo);

        void UpdateProcessResult(int transactionNumber, string processStatus, string logFilePath, string description, string isProcessed);

        void UpdateUploadHistoryByBatchFileID(int TransactionNumber, int BufferBatchFileID);

        void InsertFileLevelHash(bool isCallRedis, string fileHashSurvivalTime, string sellerID, int transactionNumber, DateTime uploadDate, string fileHashCode);

        void UpdateProcessingStep(int transactionNumber, int step);

        List<FileLevelHash> GetFileLevelHash(int transactionNumber, string sellerID, string fileHashCode);
    }
}
