﻿using MPS.Common.Web;
using MPS.DataAccess.API;
using MPS.DataAccess.Redis;
using MPS.POCO.Entity.CreateItemDownload;
using MPS.POCO.Entity.DatafeedAPI;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;

namespace MPS.DataAccess.CreateItemDownload
{
    public class NoHBaseCreateItemDownloadDAO : ICreateItemDownloadDAO
    {
        #region 改至 Config 配置

        //是否調用Datafeed API
        public static bool IsCallDatafeedAPI = false;

        #endregion 

        private SQLCreateItemDownloadDAO sqlInstance;

        public NoHBaseCreateItemDownloadDAO()
        {
            sqlInstance = new SQLCreateItemDownloadDAO();
        }

        public InboundBatchFileInfo GetInboundBatchCreateItemFileList_V2(string preTestSellerList, string emailTo, int topCount, string serverIP, int sellerType, string countryCode, string specficSellerStr)
        {
            InboundBatchFileInfo result = null;

            if (IsCallDatafeedAPI)
            {
                GetBatchFileUploadHistoryRequest QueryUploadHistory = new GetBatchFileUploadHistoryRequest()
                {
                    FileCount = topCount,
                    SellerType = sellerType.ToString(),
                    ProcessServerIP = emailTo,
                    TestSellerList = preTestSellerList,
                    CountryCode = countryCode,
                    SpecialSellerCondition = "",
                    FileType = "CreateItem",
                    IsRestrict = true
                };

                result = ApiDAO.GetUploadHistoryList(QueryUploadHistory).FirstOrDefault();
            }
            else
            {
                result = sqlInstance.GetInboundBatchCreateItemFileList_V2(preTestSellerList, emailTo, topCount, serverIP, sellerType, countryCode, specficSellerStr);
            }

            return result;
        }

        public void UpdateDataFeedFailed(int transactionNumber, string errorMessage)
        {
            if (IsCallDatafeedAPI)
            {
                UploadFileInfo UploadFileInfo = new UploadFileInfo()
                {
                    ProcessStatus = "F",
                    IsProcessed = "1",
                    BatchFileID = transactionNumber,
                    Description = errorMessage,
                    EditUser = "EDI"
                };

                bool IsPutSuccess = ApiDAO.PutUploadHistory(UploadFileInfo);
            }
            else
            {
                sqlInstance.UpdateDataFeedFailed(transactionNumber, errorMessage);
            }
        }

        public void UpdateDownloadFailed(InboundBatchFileInfo fileInfo)
        {
            if (IsCallDatafeedAPI)
            {
                UploadFileInfo UploadFileInfo = new UploadFileInfo()
                {
                    ProcessStatus = "F",
                    RetryCount = 5,
                    Description = "system issue, Please try again",
                    BatchFileID = fileInfo.TransactionNumber,
                    EditUser = "EDI"
                };

                bool IsPutSuccess = ApiDAO.PutUploadHistory(UploadFileInfo);
            }
            else
            {
                sqlInstance.UpdateDownloadFailed(fileInfo);
            }
        }

        public void UpdateProcessResult(int transactionNumber, string processStatus, string logFilePath, string description, string isProcessed)
        {
            if (IsCallDatafeedAPI)
            {
                UploadFileInfo fileInfo = new UploadFileInfo()
                {
                    BatchFileID = transactionNumber,
                    ProcessStatus = processStatus,
                    Description = description,
                    EditUser = "EDI",
                    LogFilePath = logFilePath,
                    IsProcessed = bool.Parse(isProcessed) ? "1" : "0"
                };

                bool IsPutSuccess = ApiDAO.PutUploadHistory(fileInfo);
            }
            else
            {
                sqlInstance.UpdateProcessResult(transactionNumber, processStatus, logFilePath, description, isProcessed);
            }
        }

        public void UpdateUploadHistoryByBatchFileID(int BatchFileID, int BufferBatchFileID)
        {
            if (IsCallDatafeedAPI)
            {
                InboundBatchFileInfo OldBufferItem = new InboundBatchFileInfo();

                //step 1 Get old file info                 
                GetBatchFileUploadHistoryRequest QueryUploadHistory = new GetBatchFileUploadHistoryRequest()
                {
                    BatchFileID = BufferBatchFileID,
                    FileCount = 1,
                    IsRestrict = false,
                    FileType = "CreateItem"
                };

                List<InboundBatchFileInfo> APIGetResult = ApiDAO.GetUploadHistoryList(QueryUploadHistory);

                if (APIGetResult.Count < 1) throw new Exception("APIGetResult count is zero.");

                OldBufferItem = APIGetResult[0];

                //step 2 Set update  new file info
                UploadFileInfo UploadFileInfo = new UploadFileInfo()
                {
                    BatchFileID = BatchFileID,
                    ProcessStatus = OldBufferItem.ProcessStatus,
                    IsProcessed = (OldBufferItem.IsProcessed ? "1" : "0"),
                    Description = OldBufferItem.Description,
                    LogFilePath = OldBufferItem.LogFilePath,
                    EditUser = "EDI"
                };

                bool IsPutSuccess = ApiDAO.PutUploadHistory(UploadFileInfo);
            }
            else
            {
                sqlInstance.UpdateUploadHistoryByBatchFileID(BatchFileID, BufferBatchFileID);
            }
        }

        public void InsertFileLevelHash(bool isCallRedis, string fileHashSurvivalTime, string sellerID, int transactionNumber, DateTime uploadDate, string fileHashCode)
        {
            sqlInstance.InsertFileLevelHash(isCallRedis, fileHashSurvivalTime, sellerID, transactionNumber, uploadDate, fileHashCode);
        }

        public void UpdateProcessingStep(int transactionNumber, int step)
        {
            if (IsCallDatafeedAPI)
            {
                UploadFileInfo UploadFileInfo = new UploadFileInfo()
                {
                    BatchFileID = transactionNumber,
                    ProcessSteps = step.ToString(),
                    EditUser = "EDI",
                };

                bool IsPutSuccess = ApiDAO.PutUploadHistory(UploadFileInfo);
            }
            else
            {
                sqlInstance.UpdateProcessingStep(transactionNumber, step);
            }
        }

        public List<FileLevelHash> GetFileLevelHash(int transactionNumber, string sellerID, string fileHashCode)
        {
            List<FileLevelHash> result = null;

            if (IsCallDatafeedAPI)
            {
                result = new List<FileLevelHash>();
                string redisKey = $"MKPL_CreateItem_{sellerID}_{fileHashCode}";

                using (RedisDAO redis = new RedisDAO())
                {
                    bool isRedisExists = redis.RedisContainsKey(redisKey);

                    if (isRedisExists)
                    {
                        DateTime UploadDate;

                        RedisDownload rd = redis.RedisGet<RedisDownload>(redisKey);

                        DateTime.TryParseExact(rd.UploadDate, "yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture, DateTimeStyles.None, out UploadDate);

                        FileLevelHash flh = new FileLevelHash()
                        {
                            BatchFileID = transactionNumber,
                            UploadDate = UploadDate,
                            SellerID = sellerID,
                            HashCode = fileHashCode
                        };

                        GetBatchFileUploadHistoryRequest QueryUploadHistory = new GetBatchFileUploadHistoryRequest()
                        {
                            BatchFileID = transactionNumber,
                            FileCount = 1,
                            IsRestrict = false,
                            FileType = "CreateItem"
                        };

                        List<InboundBatchFileInfo> APIGetResult = ApiDAO.GetUploadHistoryList(QueryUploadHistory);

                        bool IsRedisEffective = false;

                        if (APIGetResult.Count >= 1)
                        {
                            InboundBatchFileInfo ufInfo = APIGetResult[0];

                            if ((ufInfo.ProcessStatus == "S" || ufInfo.ProcessStatus == "F" || ufInfo.ProcessStatus == "P")
                                && (!string.IsNullOrEmpty(ufInfo.Description) && ufInfo.Description != "Init"))
                            {
                                IsRedisEffective = true;

                                if (ufInfo.ProcessStatus == "F")
                                {
                                    List<string> ErrorKeyWords = new List<string>() { "system issue, Please try again" };

                                    foreach (string keyword in ErrorKeyWords)
                                    {
                                        if (ufInfo.Description.IndexOf(keyword, StringComparison.OrdinalIgnoreCase) > -1)
                                        {
                                            if (IsRedisEffective) IsRedisEffective = false;

                                            redis.RedisRemoveKey(redisKey);

                                        }
                                    }
                                }
                            }
                        }

                        //ProcessStatcs in S F P && Description != "Init"
                        if (IsRedisEffective) result.Add(flh);
                    }
                }
            }
            else
            {
                result = sqlInstance.GetFileLevelHash(transactionNumber, sellerID, fileHashCode);
            }

            return result;
        }
    }
}