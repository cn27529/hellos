﻿using MPS.Common.Text;
using MPS.DataAccess.Redis;
using MPS.DataAccess.SQLAccess;
using MPS.POCO.Entity.CreateItemDownload;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MPS.DataAccess.CreateItemDownload
{
    public class SQLCreateItemDownloadDAO : ICreateItemDownloadDAO
    {
        public InboundBatchFileInfo GetInboundBatchCreateItemFileList_V2(string preTestSellerList, string emailTo, int topCount, string serverIP, int sellerType, string countryCode, string specficSellerStr)
        {
            DataCommand cmd = DataCommandManager.GetDataCommand("GetInboundBatchCreateItemFileList_V2");
            cmd.ReplaceParameterValue("#PreTestSellerList#", preTestSellerList);
            cmd.ReplaceParameterValue("#CountryCode#", StringParseHelper.ParseToSqlIn(countryCode));
            cmd.SetParameterValue("@SellerType", sellerType);//SellerType : PRD=1, PRDTesting=2, Sandbox=3
            cmd.SetParameterValue("@EmailTo", emailTo);
            cmd.SetParameterValue("@TopCount", topCount);
            return cmd.ExecuteEntity<InboundBatchFileInfo>();
        }

        public void UpdateDataFeedFailed(int transactionNumber, string errorMessage)
        {
            DataCommand cmd = DataCommandManager.GetDataCommand("UpdateDataFeedFailed");
            cmd.SetParameterValue("@BatchFileID", transactionNumber);
            cmd.SetParameterValue("@ErrorMessage", errorMessage);
            cmd.ExecuteNonQuery();
        }

        public void UpdateDownloadFailed(InboundBatchFileInfo fileInfo)
        {
            DataCommand cmd = DataCommandManager.GetDataCommand("UpdateDownloadFailed");
            cmd.SetParameterValue("@BatchFileID", fileInfo.TransactionNumber);
            cmd.ExecuteNonQuery();
        }

        public void UpdateProcessResult(int transactionNumber, string processStatus, string logFilePath, string description, string isProcessed)
        {
            DataCommand cmd = DataCommandManager.GetDataCommand("UpdateProcessResult");
            cmd.SetParameterValue("@TransactionNumber", transactionNumber);
            cmd.SetParameterValue("@ProcessStatus", processStatus);
            cmd.SetParameterValue("@Description", description);
            cmd.SetParameterValue("@Edituser", "EDI");
            cmd.SetParameterValue("@EditDate", DateTime.Now);
            cmd.SetParameterValue("@logFilePath", logFilePath);
            cmd.SetParameterValue("@IsProcessed", bool.Parse(isProcessed));
            cmd.ExecuteNonQuery();
        }

        public void UpdateUploadHistoryByBatchFileID(int BatchFileID, int BufferBatchFileID)
        {
            DataCommand cmd = DataCommandManager.GetDataCommand("UpdateUploadHistoryByBatchFileID");
            cmd.SetParameterValue("@BatchFileID", BatchFileID);
            cmd.SetParameterValue("@BufferBatchFileID", BufferBatchFileID);
            cmd.ExecuteNonQuery();
        }

        public void InsertFileLevelHash(bool isCallRedis, string fileHashSurvivalTime, string sellerID, int transactionNumber, DateTime uploadDate, string fileHashCode)
        {
            if (isCallRedis)
            {
                string RedisKey = $"MKPL_CreateItem_{sellerID}_{fileHashCode}";

                RedisDownload rObj = new RedisDownload()
                {
                    BatchFileID = transactionNumber,
                    UploadDate = uploadDate.ToString("yyyy-MM-dd HH:mm:ss"),
                    EditDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                };

                using (RedisDAO redis = new RedisDAO())
                {
                    redis.RedisSet<RedisDownload>(RedisKey, rObj, fileHashSurvivalTime);
                }
            }
            else
            {
                var cmd = DataCommandManager.GetDataCommand("InsertFileLevelHash");
                cmd.SetParameterValue("@SellerID", sellerID);
                cmd.SetParameterValue("@BatchFileID", transactionNumber);
                cmd.SetParameterValue("@UploadDate", uploadDate);
                cmd.SetParameterValue("@HashCode", fileHashCode);
                cmd.ExecuteNonQuery();
            }
        }

        public void UpdateProcessingStep(int transactionNumber, int step)
        {
            var cmd = DataCommandManager.GetDataCommand("UpdateProcessingStep");
            cmd.SetParameterValue("@BatchFileID", transactionNumber);
            cmd.SetParameterValue("@Step", step);
            cmd.ExecuteNonQuery();
        }

        public List<FileLevelHash> GetFileLevelHash(int transactionNumber, string sellerID, string fileHashCode)
        {
            DataCommand cmd = DataCommandManager.GetDataCommand("GetFileLevelHash");
            cmd.SetParameterValue("@SellerID", sellerID);
            cmd.SetParameterValue("@HashCode", fileHashCode);
            return cmd.ExecuteEntityList<FileLevelHash>();
        }
    }
}
