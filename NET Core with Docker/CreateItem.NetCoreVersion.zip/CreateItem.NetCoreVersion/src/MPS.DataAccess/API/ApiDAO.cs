﻿using MPS.Common.Web;
using MPS.POCO.Entity.CreateItemDownload;
using MPS.POCO.Entity.DatafeedAPI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MPS.DataAccess.API
{
    public class ApiDAO
    {
        #region 改至 Config 配置

        public static string DatafeedAPI_Key = "8305cdfe19ad428a6f662c220a42d3db";
        public static string DatafeedAPI_Token = "a04756580703b91f2aa55a5a675522db";
        public static string DataFeed_BatchFileUploadHistoryURL = "http://10.1.24.130:3000/CreateItem/BatchFileUploadHistory";

        //<add key = "DataFeed_HtmlNumberMappingURL" value="http://10.1.24.130:3000/CreateItem/HtmlNumberMapping"/>
        //<add key = "DataFeed_PropertyMapURL" value="http://10.1.24.130:3000/CreateItem/PropertyMap"/>
        //<add key = "DataFeed_ItemQAURL" value="http://10.1.24.130:3000/CreateItem/ItemQA"/>
        //<add key = "DataFeed_EmailForSuperMAPURL" value="http://10.1.24.130:3000/CreateItem/EmailForSuperMAP"/>
        //<add key = "DataFeed_SSBMessageRequestURL" value="http://10.1.24.130:3000/CreateItem/SSBMessageRequest"/>
        //<add key = "DataFeed_SSBMessageResponseURL" value="http://10.1.24.130:3000/CreateItem/SSBMessageResponse"/>
        //<add key = "DataFeed_SuperMAPURL" value="http://10.1.24.188:8009/Sandbox/V2.0.69.0/item/supermap/query"/>

        #endregion

        public static List<InboundBatchFileInfo> GetUploadHistoryList(GetBatchFileUploadHistoryRequest QueryUploadHistory)
        {
            GetBatchFileUploadHistoryResponse APIresult = 
                ServiceHelper.PostInvokeByXML<GetBatchFileUploadHistoryResponse, GetBatchFileUploadHistoryRequest>(
                    QueryUploadHistory, DataFeed_BatchFileUploadHistoryURL, "GetUploadHistoryInfo", 
                    DatafeedAPI_Key, DatafeedAPI_Token);

            List<InboundBatchFileInfo> result = null;

            if (APIresult != null && APIresult.FileUploadHistoryList.InboundBatchFileInfoList != null)
                result = APIresult.FileUploadHistoryList.InboundBatchFileInfoList;
            else
                result = new List<InboundBatchFileInfo>();

            return result;
        }

        public static bool PutUploadHistory(UploadFileInfo UploadFileInfo)
        {
            PutBatchFileUploadHistoryRequest PutUploadHistory = new PutBatchFileUploadHistoryRequest();
            PutUploadHistory.FileUploadHistoryList.UploadFileInfo = new List<UploadFileInfo>() { UploadFileInfo };

            PutBatchFileUploadHistoryResponse APIresult = 
                ServiceHelper.PutInvokeByXML<PutBatchFileUploadHistoryResponse, PutBatchFileUploadHistoryRequest>(
                    PutUploadHistory, DataFeed_BatchFileUploadHistoryURL, "BatchUpdateExcelProcessResultByAPI", 
                    DatafeedAPI_Key, DatafeedAPI_Token);

            if (APIresult != null)
            {
                if (!APIresult.IsSuccess && APIresult.ErrorStatusList.ErrorStatus != null)
                {
                    ErrorStatus Err = APIresult.ErrorStatusList.ErrorStatus;
                    throw new Exception($"PutUploadHistory API Error {Err.BatchFileID} {Err.ErrorCode} {Err.ErrorMessage}");
                }

                return APIresult.IsSuccess;
            }
            else
                throw new Exception($"PutUploadHistory no API result {UploadFileInfo.BatchFileID}");
        }
    }
}
