﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace MPS.Common.Serializer
{
    public class SerializerHelper
    {
        #region XML From File
        public static void SaveXmlSerializeEntity<T>(string filePath, object entity)
        {
            using (FileStream fs = new FileStream(filePath, FileMode.Create))
            {
                using (XmlWriter xw = XmlWriter.Create(fs))
                {
                    XmlSerializer serializer = new XmlSerializer(typeof(T));
                    serializer.Serialize(xw, entity);
                    xw.Flush();
                }
            }
        }

        public static T OpenXmlDeserializeEntity<T>(string filePath)
        {
            using (FileStream fs = new FileStream(filePath, FileMode.Open))
            {
                XmlSerializer serializer = new XmlSerializer(typeof(T));
                object obj = serializer.Deserialize(fs);
                return (T)obj;
            }
        }

        #endregion

        #region XML

        public static string XmlSerializerEntity<T>(T entity)
        {
            using (MemoryStream ms = new MemoryStream())
            {
                using (XmlWriter xw = XmlWriter.Create(ms))
                {
                    XmlSerializer xs = new XmlSerializer(entity.GetType());
                    xs.Serialize(xw, entity);
                    xw.Flush();
                }

                return Encoding.UTF8.GetString(ms.ToArray());
            }
        }

        public static string XmlSerializerEntities<T>(List<T> entities)
        {
            using (MemoryStream ms = new MemoryStream())
            {
                using (XmlWriter xw = XmlWriter.Create(ms))
                {
                    XmlSerializer xs = new XmlSerializer(entities.GetType());
                    xs.Serialize(xw, entities);
                    xw.Flush();
                }

                return Encoding.UTF8.GetString(ms.ToArray());
            }
        }

        public static T XmlDeserializeEntity<T>(string xml)
        {
            XDocument doc = XDocument.Parse(xml);
            XmlSerializer serializer = new XmlSerializer(typeof(T));

            using (XmlReader reader = doc.CreateReader())
            {
                return (T)serializer.Deserialize(reader);
            }
        }

        public static List<T> XmlDeserializeEntities<T>(string xml)
        {
            XDocument doc = XDocument.Parse(xml);
            XmlSerializer serializer = new XmlSerializer(typeof(List<T>));

            using (XmlReader reader = doc.CreateReader())
            {
                return (List<T>)serializer.Deserialize(reader);
            }
        }

        #endregion

        #region JSON

        public static string JsonSerializer<T>(T entity)
        {
            DataContractJsonSerializer js = new DataContractJsonSerializer(typeof(T));

            using (MemoryStream ms = new MemoryStream())
            {
                js.WriteObject(ms, entity);
                return Encoding.UTF8.GetString(ms.ToArray());
            }
        }

        public static T JsonDeserializeEntity<T>(string json)
        {
            DataContractJsonSerializer js = new DataContractJsonSerializer(typeof(T));

            using (MemoryStream ms = new MemoryStream(Encoding.UTF8.GetBytes(json)))
            {
                return (T)js.ReadObject(ms);
            }
        }

        public static List<T> JsonDeserializeEntities<T>(string json)
        {
            DataContractJsonSerializer js = new DataContractJsonSerializer(typeof(T));

            using (MemoryStream ms = new MemoryStream(Encoding.UTF8.GetBytes(json)))
            {
                return (List<T>)js.ReadObject(ms);
            }
        }

        #endregion JSON
    }
}
