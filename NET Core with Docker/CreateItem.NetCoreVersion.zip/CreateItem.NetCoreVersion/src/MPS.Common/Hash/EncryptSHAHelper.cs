﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Threading;
using System.Threading.Tasks;

namespace MPS.Common.Hash
{
    public class EncryptSHAHelper
    {
        public static string EncryptFile(string FilePath)
        {
            if (!System.IO.File.Exists(FilePath)) return null;

            string FileHash = string.Empty;

            using (System.IO.FileStream fs = new System.IO.FileStream(FilePath, System.IO.FileMode.Open))
            {
                SHA512 crypt = SHA512.Create();
                byte[] hashcode = crypt.ComputeHash(fs);
                FileHash = Convert.ToBase64String(hashcode);
            }

            return FileHash;
        }

        public static string EncryptFile(string FilePath, int RetryCount)
        {
            try
            {
                return EncryptFile(FilePath);
            }
            catch (Exception ex)
            {
                if (ex.Message.EndsWith("because it is being used by another process.") && RetryCount > 0)
                {
                    Thread.Sleep(100);
                    RetryCount--;
                    return EncryptFile(FilePath, RetryCount);
                }
                else
                    throw ex;
            }
        }
    }
}
