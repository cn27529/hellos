﻿using CoreFtp;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Threading;

namespace MPS.Common.FTP
{
    /// <summary>
    /// use 3 party library：CoreFTP
    /// https://github.com/sparkeh9/CoreFTP
    /// </summary>
    public class CoreFTPHelper
    {
        public static void DownloadFile(string LocalFilePath, string RemoteFileName, string HostIP, string RemotePath, string Username, string Password)
        {
            using (FtpClient ftpClient = new FtpClient(new FtpClientConfiguration { Host = HostIP, Username = Username, Password = Password }))
            {
                ftpClient.LoginAsync().Wait();
                ftpClient.ChangeWorkingDirectoryAsync(RemotePath).Wait();

                using (var ftpReadStream = ftpClient.OpenFileReadStreamAsync(RemoteFileName).Result)
                {
                    FileInfo tempFile = new FileInfo(LocalFilePath);

                    using (var fileWriteStream = tempFile.OpenWrite())
                    {
                        ftpReadStream.CopyToAsync(fileWriteStream).Wait();
                    }
                }
            }
        }

        public static void UploadFile(string LocalFilePath, string RemoteFileName, string HostIP, string RemotePath, string Username, string Password)
        {
            using (var ftpClient = new FtpClient(new FtpClientConfiguration { Host = HostIP, Username = Username, Password = Password }))
            {
                ftpClient.LoginAsync().Wait();
                ftpClient.ChangeWorkingDirectoryAsync(RemotePath).Wait();

                using (var writeStream = ftpClient.OpenFileWriteStreamAsync(RemoteFileName).Result)
                {
                    FileInfo fileinfo = new FileInfo(LocalFilePath);
                    var fileReadStream = fileinfo.OpenRead();
                    fileReadStream.CopyToAsync(writeStream).Wait();
                }
            }
        }

        public static void DeleteFile(string RemoteFileName, string HostIP, string RemotePath, string Username, string Password)
        {
            using (var ftpClient = new FtpClient(new FtpClientConfiguration { Host = HostIP, Username = Username, Password = Password }))
            {
                ftpClient.LoginAsync().Wait();
                ftpClient.ChangeWorkingDirectoryAsync(RemotePath).Wait();
                ftpClient.DeleteFileAsync(RemoteFileName).Wait();
            }
        }
    }
}
