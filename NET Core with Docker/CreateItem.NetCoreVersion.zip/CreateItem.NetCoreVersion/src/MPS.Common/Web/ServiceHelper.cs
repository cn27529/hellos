﻿using MPS.Common.Serializer;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Net;

namespace MPS.Common.Web
{
    public class ServiceHelper
    {
        public enum ServiceMethodType
        {
            GET,
            POST,
            PUT,
            DELETE
        }

        /// <summary>
        /// 調用 POST REST Service 使用 XML 格式
        /// </summary>
        /// <typeparam name="T">Response Class</typeparam>
        /// <typeparam name="K">Request Class</typeparam>
        /// <param name="request">Request Object</param>
        /// <param name="serviceURL">Service URL</param>
        /// <returns></returns>
        public static T PostInvokeByXML<T, K>(K request, string serviceURL, string logFileName, string key, string token)
        {
            string RequestXML = SerializerHelper.XmlSerializerEntity<K>(request);
            string ResponseXML = CallServiceByXML(serviceURL, ServiceMethodType.POST, RequestXML, key, token);
            return SerializerHelper.XmlDeserializeEntity<T>(ResponseXML);
        }

        /// <summary>
        /// 調用 PUT REST Service 使用 XML 格式
        /// </summary>
        /// <typeparam name="T">Response Class</typeparam>
        /// <typeparam name="K">Request Class</typeparam>
        /// <param name="request">Request Object</param>
        /// <param name="serviceURL">Service URL</param>
        /// <returns></returns>
        public static T PutInvokeByXML<T, K>(K request, string serviceURL, string logFileName, string key, string token)
        {
            string RequestXML = SerializerHelper.XmlSerializerEntity<K>(request);
            string ResponseXML = CallServiceByXML(serviceURL, ServiceMethodType.PUT, RequestXML, key, token);
            return SerializerHelper.XmlDeserializeEntity<T>(ResponseXML);
        }

        /// <summary>
        /// 調用 REST Service 使用 XML 格式
        /// </summary>
        /// <param name="serviceURL"></param>
        /// <param name="methodType"></param>
        /// <param name="requestXML"></param>
        /// <param name="key"></param>
        /// <param name="token"></param>
        /// <returns></returns>
        public static string CallServiceByXML(string serviceURL, ServiceMethodType methodType, string requestXML, string key, string token)
        {
            HttpWebRequest Request = null;

            try
            {
                Request = (HttpWebRequest)WebRequest.Create(serviceURL);
                Request.Method = methodType.ToString();
                Request.Accept = "application/xml";
                Request.ContentType = "application/xml";
                Request.Proxy = null;

                if (!string.IsNullOrWhiteSpace(key) && !string.IsNullOrWhiteSpace(token))
                    Request.Headers["Authorization"] = $"{key}&{token}";

                Stream DataStream;

                if (!string.IsNullOrEmpty(requestXML))
                {
                    byte[] ByteArray = Encoding.UTF8.GetBytes(requestXML);
                    //Request.ContentLength = ByteArray.Length;

                    using (DataStream = Request.GetRequestStreamAsync().Result)
                    {
                        DataStream.Write(ByteArray, 0, ByteArray.Length);
                    }
                }

                using (WebResponse Response = Request.GetResponseAsync().Result)
                {
                    using (DataStream = Response.GetResponseStream())
                    {
                        using (StreamReader Reader = new StreamReader(DataStream))
                        {
                            XmlDocument Doc = new XmlDocument();
                            Doc.LoadXml(Reader.ReadToEnd());
                            return Doc.InnerXml;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                if (Request != null) Request.Abort();

                throw ex;
            }
        }

        public static void CallSpiderLogServiceByJson(string serviceURL, string requestJson)
        {
            HttpWebRequest Request = null;

            try
            {
                Request = (HttpWebRequest)WebRequest.Create(serviceURL);
                Request.Method = "POST";
                Request.Accept = "application/json";
                Request.ContentType = "application/json";
                Request.Proxy = null;

                byte[] byteContent = Encoding.ASCII.GetBytes(requestJson);

                using (Stream reqStream = Request.GetRequestStreamAsync().Result)
                {
                    reqStream.Write(byteContent, 0, byteContent.Length);
                }

                using (WebResponse wr = Request.GetResponseAsync().Result)
                {
                    var statusCode = ((HttpWebResponse)wr).StatusCode;
                }
            }
            catch (Exception ex)
            {
                if (Request != null) Request.Abort();

                throw ex;
            }
        }
    }
}
