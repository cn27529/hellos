﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace MPS.Common.Web
{
    public class InternetHelper
    {
        /// <summary>
        /// 取得本地IP位址
        /// </summary>
        /// <returns></returns>
        public static string GetIPAddress()
        {
            IPHostEntry iphostentry = Dns.GetHostEntryAsync(Dns.GetHostName()).Result;
            IPAddress SvrIP = iphostentry.AddressList[iphostentry.AddressList.Length - 1];
            return SvrIP.ToString();
        }
    }
}
