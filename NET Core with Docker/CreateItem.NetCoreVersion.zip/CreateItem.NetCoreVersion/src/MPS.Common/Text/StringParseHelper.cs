﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MPS.Common.Text
{
    public class StringParseHelper
    {
        /// <summary>
        /// "A,B,C" to "'A','B','C'"
        /// </summary>
        /// <param name="source"></param>
        /// <returns></returns>
        public static string ParseToSqlIn(string source)
        {
            string[] temp = source.Split(',');

            for (int i = 0; i < temp.Length; i++)
            {
                temp[i] = $"'{temp[i]}'";
            }

            return string.Join(",", temp);
        }
    }
}
