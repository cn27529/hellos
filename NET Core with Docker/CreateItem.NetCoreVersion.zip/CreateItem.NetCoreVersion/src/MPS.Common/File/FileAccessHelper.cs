﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MPS.Common.File
{
    public class FileAccessHelper
    {
        #region 改至 Config 配置

        public static string DatafeedBaseDir = @"D:\Application\EnterpriseShare.Core\MKTPLS.Service";

        #endregion

        public static void MoveFileToBackUp(string sellerID, string localFilePath)
        {
            if (System.IO.File.Exists(localFilePath))
            {
                System.IO.FileInfo localFi = new System.IO.FileInfo(localFilePath);
                System.IO.DirectoryInfo destDi = System.IO.Directory.GetParent(DatafeedBaseDir);
                string destFilePath = System.IO.Path.Combine(
                    destDi.FullName, "Backup", sellerID, "CreateItem", DateTime.Now.ToString("yyyy-MM-dd"), localFi.Name);
                System.IO.FileInfo destFi = new System.IO.FileInfo(destFilePath);

                if (!destFi.Directory.Exists) destFi.Directory.Create();

                if (!System.IO.File.Exists(destFilePath)) localFi.MoveTo(destFilePath);
            }
        }
    }
}
