﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace MPS.POCO.Entity.DatafeedAPI
{
    public class GetBatchFileUploadHistoryRequest
    {
        public int? BatchFileID { get; set; }

        [XmlIgnore]
        public bool BatchFileIDSpecified { get { return (BatchFileID != null && BatchFileID.HasValue); } }

        [XmlElement(IsNullable = false)]
        public string SellerType { get; set; }

        [XmlElement(IsNullable = false)]
        public string ProcessServerIP { get; set; }

        [XmlElement(IsNullable = false)]
        public string TestSellerList { get; set; }

        [XmlElement(IsNullable = false)]
        public string CountryCode { get; set; }

        [XmlElement(IsNullable = false)]
        public string SpecialSellerCondition { get; set; }

        [XmlElement(IsNullable = false)]
        public bool IsRestrict { get; set; }

        [XmlElement(IsNullable = false)]
        public string FileType { get; set; }

        [XmlElement(IsNullable = false)]
        public int FileCount { get; set; }
    }
}
