﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace MPS.POCO.Entity.DatafeedAPI
{
    [XmlRoot(ElementName = "ResponseStatus")]
    public class PutBatchFileUploadHistoryResponse
    {
        [XmlElement(ElementName = "IsSuccess")]
        public bool IsSuccess { get; set; }

        [XmlElement(ElementName = "ErrorStatusList")]
        public ErrorStatusList ErrorStatusList { get; set; }
    }

    [XmlRoot(ElementName = "ErrorStatus")]
    public class ErrorStatus
    {
        public string ErrorCode { get; set; }

        public string ErrorMessage { get; set; }

        public int BatchFileID { get; set; }
    }

    [XmlRoot(ElementName = "ErrorStatusList")]
    public class ErrorStatusList
    {
        [XmlElement(ElementName = "ErrorStatus")]
        public ErrorStatus ErrorStatus { get; set; }
    }
}
