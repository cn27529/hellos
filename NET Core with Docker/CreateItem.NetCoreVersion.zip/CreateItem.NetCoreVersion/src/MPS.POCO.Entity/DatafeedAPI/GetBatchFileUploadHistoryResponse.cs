﻿using MPS.POCO.Entity.CreateItemDownload;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace MPS.POCO.Entity.DatafeedAPI
{
    public class GetBatchFileUploadHistoryResponse
    {
        public FileUploadHistoryList FileUploadHistoryList { get; set; }
    }

    public class FileUploadHistoryList
    {
        [XmlElement(ElementName = "InboundBatchFileInfo")]
        public List<InboundBatchFileInfo> InboundBatchFileInfoList { get; set; }
    }
}
