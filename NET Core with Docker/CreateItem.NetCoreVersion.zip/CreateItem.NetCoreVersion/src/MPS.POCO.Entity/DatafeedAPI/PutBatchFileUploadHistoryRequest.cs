﻿using MPS.POCO.Entity.CreateItemDownload;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace MPS.POCO.Entity.DatafeedAPI
{
    [XmlRoot(ElementName = "UpdateBatchFileUploadHistoryRequest")]
    public class PutBatchFileUploadHistoryRequest
    {
        [XmlElement(ElementName = "FileUploadHistoryList")]
        public PutFileUploadHistoryList FileUploadHistoryList { get; set; }

        public PutBatchFileUploadHistoryRequest()
        {
            FileUploadHistoryList = new PutFileUploadHistoryList();
        }
    }

    public class PutFileUploadHistoryList
    {
        [XmlElement(ElementName = "UploadFileInfo")]
        public List<UploadFileInfo> UploadFileInfo { get; set; }
    }
}
