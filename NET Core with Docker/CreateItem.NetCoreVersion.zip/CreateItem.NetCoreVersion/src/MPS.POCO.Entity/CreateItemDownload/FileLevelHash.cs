﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MPS.POCO.Entity.CreateItemDownload
{
    public class FileLevelHash
    {
        public int BatchFileID { get; set; }

        public string SellerID { get; set; }

        public DateTime UploadDate { get; set; }

        public string HashCode { get; set; }
    }
}
