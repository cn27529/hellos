﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MPS.POCO.Entity.CreateItemDownload
{
    public class InboundBatchFileInfo
    {
        public int TransactionNumber { get; set; }

        public string SellerID { get; set; }

        public string FileType { get; set; }

        public string SourceFileName { get; set; }

        public string FTPFilePath { get; set; }

        public string LanguageCode { get; set; }

        public int CompanyCode { get; set; }

        public string CountryCode { get; set; }

        public string Description { get; set; }

        public string LogFilePath { get; set; }

        public int UserID { get; set; }

        public int CustomerID { get; set; }

        public bool IsProcessed { get; set; }

        public int RetryCount { get; set; }

        public string UploadUser { get; set; }

        public string ClientIP { get; set; }

        /*
         * 1. 表示文件下载完成
         * 2. 表示处理完成
         * 3. 表示上传完成
         */
        public string ProcessSteps { get; set; }

        public long FileSize { get; set; }

        //txt，xls，csv，xml
        public string FileFormatType { get; set; }

        public string UserStatus { get; set; }

        public string ErrorMessage { get; set; }

        public int IsCanDownload { get; set; }

        public int IsInHash { get; set; }

        public int BufferBatchFileID { get; set; }

        public bool IsDuplicateFile { get; set; }

        public string FileHashCode { get; set; }

        public string ProcessStatus { get; set; }

        public string bufferPath_tmp { get; set; }

        public string bufferPath { get; set; }

        public string EmailTo { get; set; }

        public DateTime UploadDate { get; set; }

        public string UploadedDate
        {
            get { return UploadDate.ToString(); }
            set
            {
                DateTime _value;

                if (DateTime.TryParse(value, out _value)) UploadDate = _value;
            }
        }

        public FileLevelHash BufferFileHashInfo { get; set; }
    }
}
