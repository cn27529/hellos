﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MPS.POCO.Entity.CreateItemDownload
{
    public class RedisDownload
    {
        public int BatchFileID { get; set; }

        public string UploadDate { get; set; }

        public string EditDate { get; set; }
    }
}
