﻿using MPS.Common.FTP;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Threading;
using MPS.Common.Hash;
using MPS.BatchCreateItemDownload.Business;
using MPS.Common.Web;
using MPS.POCO.Entity.CreateItemDownload;
using MPS.DataAccess.CreateItemDownload;
using MPS.DataAccess;
using MPS.Common.Text;
using MPS.Common.File;
using MPS.DataAccess.Redis;
using MPS.DataAccess.SpiderLog;

namespace MPS.BatchCreateItemDownload
{
    public class HandleFileProcess
    {
        #region 改至 Config 配置

        //測試 Seller 清單
        public static string PreTestSellerList = StringParseHelper.ParseToSqlIn("A001,A006");
        //0:Test 1:PRD 2:Sandbox
        public static int RunMode = 0;
        //要處理的 CountryCode
        public static string CountryCode = "USA";
        //C:\Users\sl8p\Desktop\CreateItem.NetCoreVersion\src\RunConsoleApp\bin\Debug\netcoreapp1.0\Inbound
        public static string BatchFileBasePath = Path.Combine(AppContext.BaseDirectory,"Inbound");
        //檔案從FTP下載回來放置的路徑
        //C:\Users\sl8p\Desktop\CreateItem.NetCoreVersion\src\RunConsoleApp\bin\Debug\netcoreapp1.0\Inbound\Download
        public static string DownloadFileBufferPath = Path.Combine(BatchFileBasePath, "Download");
        //DownloadJob處理完畢後檔案放置的路徑
        //C:\Users\sl8p\Desktop\CreateItem.NetCoreVersion\src\RunConsoleApp\bin\Debug\netcoreapp1.0\Inbound\DocTransform
        public static string InboundDocTransformPath = Path.Combine(BatchFileBasePath, "DocTransform");
        //FTP路徑資訊配置
        public static string FTPServerIP = "10.1.24.72";
        public static string FTPRemotePath = "MKTPLS_Batch/Inbound/CreateItem/";
        public static string FTPUserName = "";
        public static string FTPUserPassword = "";
        //是否啟用重複檔案檢查
        public static bool IsCheckFileDuplicate = true;
        //是否寫入Redis
        public static bool IsCallRedis = true;
        //是否寫入Spider Log
        public static bool IsWriteSpiderLog = true;
        //File Hash值在 Redis 的生存時間
        public static string FileHashSurvivalTime = "7.00:00:00";

        #endregion

        public bool IsRun { get; set; }
        public string ServerIP { get; set; }
        public InboundBatchFileInfo CurrentFile { get; set; }

        private ICreateItemDownloadDAO DataAccess;

        public HandleFileProcess()
        {
            IsRun = true;
            ServerIP = InternetHelper.GetIPAddress();
            DataAccess = DBFactory.GetCreateItemDownloadInstance();
            CurrentFile = GetDownloadFileInfo();
        }

        public void Run()
        {
            try
            {
                if (CurrentFile == null)
                {
                    Console.WriteLine("HandleFileProcess Run process done. No file need to process.");
                    return;
                }

                if (CurrentFile.IsCanDownload == 0)
                {
                    DataAccess.UpdateDataFeedFailed(CurrentFile.TransactionNumber, CurrentFile.ErrorMessage.Length <= 100 ?
                        CurrentFile.ErrorMessage : CurrentFile.ErrorMessage.Substring(0, 99));
                    DeleteFtpFile();
                    Console.WriteLine($"HandleFileProcess Run process done. File can not download. BatchFileID：{CurrentFile.TransactionNumber} SellerID：{CurrentFile.SellerID} CountryCode：{CurrentFile.CountryCode} ErrorMessage：{CurrentFile.ErrorMessage}");
                    return;
                }

                bool isSellerRightAndProcess = SellerInfo.CheckSellerRightAndProcess(CurrentFile, DataAccess);

                if (!isSellerRightAndProcess)
                {
                    //TODO 刪除 FTP 原始檔? DeleteFtpFile();
                    Console.WriteLine($"HandleFileProcess Run process done. Check seller not right and process. BatchFileID：{CurrentFile.TransactionNumber} SellerID：{CurrentFile.SellerID} CountryCode：{CurrentFile.CountryCode}");
                    return;
                }

                DateTime? chkDupFileStart = null;
                bool isDownloadSuccess = DownloadFtpFile(ref chkDupFileStart);
                string RedisKey = $"MKPL_CreateItem_{CurrentFile.SellerID}_{CurrentFile.FileHashCode}";

                if (!isDownloadSuccess)
                {
                    DataAccess.UpdateDownloadFailed(CurrentFile);

                    if (File.Exists(CurrentFile.bufferPath_tmp)) File.Delete(CurrentFile.bufferPath_tmp);

                    Console.WriteLine($"HandleFileProcess Run process done. FTP file download Fail. BatchFileID：{CurrentFile.TransactionNumber} SellerID：{CurrentFile.SellerID} CountryCode：{CurrentFile.CountryCode}");
                    return;
                }

                if (!IsCheckFileDuplicate) CurrentFile.IsDuplicateFile = false;

                int BufferBatchFileID = 0;

                if (CurrentFile.IsInHash == 1)
                    BufferBatchFileID = CurrentFile.BufferBatchFileID;
                else
                    BufferBatchFileID = CurrentFile.BufferFileHashInfo.BatchFileID;

                if (CurrentFile.IsDuplicateFile && CurrentFile.IsInHash != 1)
                {
                    if (BufferBatchFileID > 0)
                        DataAccess.UpdateUploadHistoryByBatchFileID(CurrentFile.TransactionNumber, BufferBatchFileID);

                    if (File.Exists(CurrentFile.bufferPath_tmp))
                    {
                        //D:\Application\EnterpriseShare.Core\Backup\{SellerID}\CreateItem\2015-04-21\A006_BatchCreation_20161208_160124557.O.10611.7455162.USA.xls
                        FileAccessHelper.MoveFileToBackUp(CurrentFile.SellerID, CurrentFile.bufferPath_tmp);
                    }

                    DeleteFtpFile();

                    if (IsWriteSpiderLog && IsCheckFileDuplicate) DownLoadSpiderLog(CurrentFile.TransactionNumber, chkDupFileStart);

                    Console.WriteLine($"HandleFileProcess Run process done. This is duplicate file. BatchFileID：{CurrentFile.TransactionNumber} SellerID：{CurrentFile.SellerID} CountryCode：{CurrentFile.CountryCode}");

                    return;
                }

                if (IsCheckFileDuplicate && !string.IsNullOrEmpty(CurrentFile.FileHashCode))
                {
                    DataAccess.InsertFileLevelHash(IsCallRedis, FileHashSurvivalTime, CurrentFile.SellerID, CurrentFile.TransactionNumber, CurrentFile.UploadDate, CurrentFile.FileHashCode);
                }

                //標示檔案下載結果，若下載成功，則更新 dbo.EDI_Seller_BatchFileUploadStatusHistory 資料表的 ProcessSteps = 1
                DataAccess.UpdateProcessingStep(CurrentFile.TransactionNumber, 1);

                if (File.Exists(CurrentFile.bufferPath_tmp))
                {
                    if (!File.Exists(CurrentFile.bufferPath))
                    {
                        File.Move(CurrentFile.bufferPath_tmp, CurrentFile.bufferPath);
                        Console.WriteLine($"Move File {CurrentFile.bufferPath_tmp} To \r\n{CurrentFile.bufferPath}");
                    }
                    else
                    {
                        File.Delete(CurrentFile.bufferPath_tmp);
                        Console.WriteLine($"File Exists {CurrentFile.bufferPath} \r\nDelete File {CurrentFile.bufferPath_tmp}");
                    }
                }

                Console.WriteLine($"HandleFileProcess Run process done. Process success. BatchFileID：{CurrentFile.TransactionNumber} SellerID：{CurrentFile.SellerID} CountryCode：{CurrentFile.CountryCode}");

                if (IsWriteSpiderLog && IsCheckFileDuplicate) DownLoadSpiderLog(CurrentFile.TransactionNumber, chkDupFileStart);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"HandleFileProcess Run Exception. BatchFileID：{CurrentFile.TransactionNumber} SellerID：{CurrentFile.SellerID} CountryCode：{CurrentFile.CountryCode} \r\n{ex.Message} \r\n{ex.StackTrace}");
                throw ex;
            }
            finally
            {
                Console.WriteLine("MPS.BatchCreateItemDownload HandleFileProcess Run Completed.");
            }
        }

        /// <summary>
        /// 取得BatchUploadHistory表中需處理的資料
        /// </summary>
        /// <returns></returns>
        private InboundBatchFileInfo GetDownloadFileInfo()
        {
            string mailTo = $"{ServerIP}:0";
            InboundBatchFileInfo fileInfo = DataAccess.GetInboundBatchCreateItemFileList_V2(
                PreTestSellerList, mailTo, 1, ServerIP, RunMode, CountryCode, "");

            if (fileInfo != null)
                Console.WriteLine($"GetDownloadFileInfo get data. BatchFileID：{fileInfo.TransactionNumber} SellerID：{fileInfo.SellerID} EmailTo：{fileInfo.EmailTo}");
            else
                Console.WriteLine($"GetDownloadFileInfo get no data.");

            return fileInfo;
        }

        /// <summary>
        /// 從FTP下載檔案
        /// </summary>
        /// <param name="checkDuplicateStartTime"></param>
        /// <returns></returns>
        private bool DownloadFtpFile(ref DateTime? checkDuplicateStartTime)
        {
            string ftpFileName = Path.GetFileName(CurrentFile.FTPFilePath);
            string localFileName = $"{Path.GetFileNameWithoutExtension(ftpFileName)}.{ CurrentFile.UserStatus.ToUpper()}.{CurrentFile.TransactionNumber}.{CurrentFile.CustomerID}.{CurrentFile.CountryCode.ToUpper()}{Path.GetExtension(ftpFileName)}";
            string localBufferPath = Path.Combine(DownloadFileBufferPath, localFileName);

            if (!Directory.Exists(DownloadFileBufferPath)) Directory.CreateDirectory(DownloadFileBufferPath);

            string inboundDocTransformPath = Path.Combine(InboundDocTransformPath, localFileName);

            if (!Directory.Exists(InboundDocTransformPath)) Directory.CreateDirectory(InboundDocTransformPath);

            int retryCount = 0;
            bool isDownloadSuccess = false;

            while (!isDownloadSuccess)
            {
                try
                {
                    CoreFTPHelper.DownloadFile(
                        localBufferPath, ftpFileName, FTPServerIP, FTPRemotePath, FTPUserName, FTPUserPassword);
                    isDownloadSuccess = true;
                    Console.WriteLine($"DownloadFtpFile DownloadFile Success. \r\nftp://{FTPServerIP}/{FTPRemotePath}{ftpFileName} To \r\n{localBufferPath}");
                }
                catch (Exception ex)
                {
                    if (retryCount >= 5)
                        return false;
                    else
                    {
                        Console.WriteLine($"DownloadFtpFile DownloadFile Exception. RetryCount：{retryCount} \r\n{ex.Message} \r\n{ex.StackTrace}");
                        Thread.Sleep(1000);
                        retryCount++;
                    }
                }
            }

            CurrentFile.IsDuplicateFile = false;
            CurrentFile.BufferFileHashInfo = new FileLevelHash();

            if (IsCheckFileDuplicate)
            {
                checkDuplicateStartTime = DateTime.Now;

                if (File.Exists(localBufferPath))
                    CurrentFile.FileHashCode = EncryptSHAHelper.EncryptFile(localBufferPath);

                if (!string.IsNullOrEmpty(CurrentFile.FileHashCode))
                {
                    if (IsCallRedis)
                    {
                        CurrentFile.IsInHash = 0;

                        try
                        {
                            string RedisKey = $"MKPL_CreateItem_{CurrentFile.SellerID}_{CurrentFile.FileHashCode}";

                            using (RedisDAO redis = new RedisDAO())
                            {
                                RedisDownload rObj = redis.RedisGet<RedisDownload>(RedisKey);

                                if (rObj != null)
                                {
                                    if (CurrentFile.TransactionNumber == rObj.BatchFileID) CurrentFile.IsInHash = 1;
                                }
                                else
                                {
                                    bool isRedisKeyExists = redis.RedisContainsKey(RedisKey);

                                    if (isRedisKeyExists) redis.RedisRemoveKey(RedisKey);
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine($"DownloadFile CallRedis Exception. \r\n{ex.Message} \r\n{ex.StackTrace}");
                        }
                    }

                    if (CurrentFile.IsInHash != 1)
                    {
                        List<FileLevelHash> localFileHashs = DataAccess.GetFileLevelHash(CurrentFile.TransactionNumber, CurrentFile.SellerID, CurrentFile.FileHashCode);

                        if (localFileHashs.Count > 0)
                        {
                            CurrentFile.IsDuplicateFile = true;
                            CurrentFile.BufferFileHashInfo = localFileHashs[0];
                        }
                    }
                }
            }
            else
                CurrentFile.IsDuplicateFile = false;

            CurrentFile.bufferPath = inboundDocTransformPath;
            CurrentFile.bufferPath_tmp = localBufferPath;
            return true;
        }

        /// <summary>
        /// 刪除FTP上的原始檔
        /// </summary>
        private void DeleteFtpFile()
        {
            int retryCount = 0;
            bool isDeleteSuccess = false;

            while (!isDeleteSuccess)
            {
                try
                {
                    string ftpFileName = Path.GetFileName(CurrentFile.FTPFilePath);
                    CoreFTPHelper.DeleteFile(ftpFileName, FTPServerIP, FTPRemotePath, FTPUserName, FTPUserPassword);
                    isDeleteSuccess = true;
                    Console.WriteLine($"DeleteFtpFile Success. ftp://{FTPServerIP}/{FTPRemotePath}/{ftpFileName}");
                }
                catch (Exception ex)
                {
                    if (retryCount >= 5)
                        throw ex;
                    else
                    {
                        Console.WriteLine($"DeleteFtpFile Exception. RetryCount：{retryCount} \r\n{ex.Message} \r\n{ex.StackTrace}");
                        Thread.Sleep(1000);
                        retryCount++;
                    }
                }
            }
        }

        public static void DownLoadSpiderLog(int batchFileID, DateTime? dtStart)
        {
            string tAction = "FilelevelDuplicateCheck";
            string tLabel = "Item count:1";
            SpiderLogDAO.CallSpiderLogV1(tAction, tLabel, dtStart);
        }
    }
}
