﻿using MPS.DataAccess;
using MPS.DataAccess.CreateItemDownload;
using MPS.POCO.Entity.CreateItemDownload;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MPS.BatchCreateItemDownload.Business
{
    public class SellerInfo
    {
        public enum SellerStatus
        {
            New = 'N',
            Open = 'O',
            Suspended = 'S',
            Terminated = 'T',
            Inactive = 'D',
            Closed = 'C'
        }

        public static bool CheckSellerRight(InboundBatchFileInfo file, out string errorMsg)
        {
            var result = true;
            errorMsg = string.Empty;
            SellerStatus sellerStatus = (SellerStatus)(char.Parse(file.UserStatus.ToUpper()));

            if (file.FileType.Trim().ToUpper() == "CREATEITEM")
            {
                if (sellerStatus == SellerStatus.Suspended || sellerStatus == SellerStatus.Terminated
                    || sellerStatus == SellerStatus.Closed || sellerStatus == SellerStatus.New)
                {
                    result = false;
                }
            }

            if (!result)
            {
                switch (sellerStatus)
                {
                    case SellerStatus.Suspended:
                        errorMsg = "SellerNoRightError_suspended"; break;
                    case SellerStatus.Terminated:
                        errorMsg = "SellerNoRightError_terminated"; break;
                    case SellerStatus.Closed:
                        errorMsg = "SellerNoRightError_closed"; break;
                    case SellerStatus.New:
                        errorMsg = "SellerNoRightError_new"; break;
                }
            }

            return result;
        }

        /// <summary>
        /// 檢查Seller存取權限,若SellerStatus為Terminated,Closed,New就回傳false
        /// </summary>
        /// <param name="currentFile"></param>
        /// <param name="dataAccess"></param>
        /// <returns></returns>
        public static bool CheckSellerRightAndProcess(InboundBatchFileInfo currentFile, ICreateItemDownloadDAO dataAccess)
        {
            string errorMsg;
            bool result = CheckSellerRight(currentFile, out errorMsg);

            Console.WriteLine($"CheckSellerRightAndProcess CheckSellerRight. BatchFileID：{currentFile.TransactionNumber} SellerID：{currentFile.SellerID} Result：{result}");

            if (!result)
            {
                dataAccess.UpdateProcessResult(currentFile.TransactionNumber, "F", string.Empty, errorMsg, "True");
                Console.WriteLine($"CheckSellerRightAndProcess UpdateProcessResult. BatchFileID：{currentFile.TransactionNumber} ErrorMsg：{errorMsg}");
            }

            return result;
        }
    }
}
